package com.pro;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Hello {
	
	@RequestMapping("/Add")
	public ModelAndView Add(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out =response.getWriter();
		String name=request.getParameter("t1");
		String pa=request.getParameter("t2");
		String pas=request.getParameter("t3");
	
		
		RequestDispatcher rd;
		ModelAndView mv=new ModelAndView();
		
		if(!pa.equals(pas))
		{
			mv.setViewName("display.jsp");
			mv.addObject("su","Password mismatch try agin.!");
					
		}
		else
		{
			
			mv.setViewName("notnull.jsp");
			mv.addObject("sum",name);
						
		}
		
		return mv;
	
		
	}
	

}
