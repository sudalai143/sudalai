package mypro;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class arraylist {
		public static void main(String[] args) 
		{			
		       List l=new ArrayList();
		       System.out.println("Enter the name");
		       Scanner input=new Scanner(System.in);
		       
		       
		       String a =input.nextLine();
		       l.add(a);
		       
		       
		       System.out.println("Enter physics marks");
		       Scanner inpu=new Scanner(System.in);
		       
		       int b=inpu.nextInt();
		       l.add(b);
		       
		       System.out.println("Enter chemistry marks");
		       Scanner inp=new Scanner(System.in);
		       
		       int c=inp.nextInt();
		       l.add(c);
		       
		       System.out.println("Enter mathematics marks");
		       Scanner in=new Scanner(System.in);
		       
		       int d=in.nextInt();
		       l.add(d);
		       
		       System.out.println("Enter biology marks");
		       Scanner im=new Scanner(System.in);
		       
		       int e=im.nextInt();
		       l.add(e);
		       
		       System.out.println("Enter hindi marks");
		       Scanner nm=new Scanner(System.in);
		       
		       int f=nm.nextInt();
		       l.add(f);
		       
		       
		       System.out.println("Enter english marks");
		       Scanner ip=new Scanner(System.in);
		       
		       int cg=inp.nextInt();
		       l.add(cg);
		    
		       for (int i = 0; i < l.size(); i++)
		       {
		          System.out.println(l.get(i));
		           
		       } 
		              
		}
}


